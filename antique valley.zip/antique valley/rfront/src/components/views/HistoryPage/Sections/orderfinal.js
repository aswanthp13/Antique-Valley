import React, { useEffect, useState } from 'react'
import { Row, Col } from 'antd';
import axios from 'axios'
function OrderFinal(props) {
   
    var [uploaddata,setUploaddata]= useState("")
    var [address,setAddress]= useState("")

    useEffect(() => {
        // Axios.get(`/api/product/products_by_id?id=${productId}&type=single`)
        //     .then(response => {
        //         setProduct(response.data[0])
        //     })
        getFuc();
        getAdr();

    }, [])

    const getAdr=()=>{
        axios.get(`/api/address/addressbyid`)
          .then(response =>{
              if(response.data){
                console.log(response.data);
                setAddress(response.data.address);
              }
          });
    }

    const getFuc=()=>{
        axios.get(`/api/users/userOrderInfo`)
          .then(response =>{
              if(response.data){
                console.log(response.data);
                setUploaddata(response.data.orderDetail);
              }
          });
    }

    const addAddress = () =>{
        props.history.push('/address')
    }

    const Confirm = () =>{
        if( document.getElementById("red").checked == true){
       alert(' Ordered Successfully ')
       props.history.push('/history')
        }
        else{
            alert("Choose Address")
        }
    }

    return (
        <div className="postPage" style={{ width: '100%', padding: '3rem 4rem' }}>

            <div style={{ display: 'flex', justifyContent: 'center' }}>
                <h1>Order Confirm</h1>
            </div>

            <br />

            <Row gutter={[16, 16]} >
                <Col lg={12} xs={24}>
                <div>
                     {  uploaddata && uploaddata.length!==0 && uploaddata.map((item,i) =>       
                    <div key={i}>     
                        <div>        
                       <img  style={{width:'180px',height:'180px'}} src={item.images&&`http://localhost:5000/${item.images[0]}`}  />
                       </div> <br/>
                        <h1  style={{marginTop:"50px"}}>  {item.title} </h1>
                        <h1>Price: {item.price} </h1>
                        <p>{item.description}</p>
                    </div>)} 
                </div>
                </Col>
                <Col lg={12} xs={24}>
                   
                    <div>
                    <h2>Your Address</h2>
                      <p> <button onClick={addAddress}>Add Address</button> </p>
                    {  address && address.length!==0 && address.map((item,i) =>       
                    <div  style={{marginTop:"40px"}} key={i}>     
                        <input type="radio" id="red"/>
                        <p >  {item.name} </p>
                        <p>{item.houseName} ,  {item.area}  {item.city} {item.landmark}</p>
                        <p> {item.mobile} </p>
                        <p>{item.state} ,{item.country}  </p>
                    </div>)} 
                     <p> Delivery Method: COD </p>
                    <button onClick={Confirm}>Confirm </button>
                    </div>
                </Col>
            </Row>

            <div style={{marginTop:"100px"}}>
            <hr/>
            </div>

            {/* <div style={{marginTop:"100px"}}>
              <center> <h1>Table Here</h1></center> 
            </div> */}

        </div>
    )
}

export default OrderFinal
