import React, { useState } from 'react'
import { Typography, Button, Form, message, Input, Icon } from 'antd';
import axios from 'axios';
{/* <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"></link> */}
const { Title } = Typography;
const { TextArea } = Input;

function AddressPage(props) {

    const [NameValue, setNameValue] = useState("")
    const [MobileValue, setMobileValue] = useState("")
    const [HouseNameValue, setHouseNameValue] = useState("")
    const [PincodeValue, setPincodeValue] = useState("")
    const [AreaValue, setAreaValue] = useState("")
    const [LandmarkValue, setLandmarkValue] = useState("")
    const [CityValue, setCityValue] = useState("")
    const [StateValue, setStateValue] = useState("")
    const [CountryValue, setCountryValue] = useState("")



    const onNameChange = (event) => {
        setNameValue(event.currentTarget.value)
    }

    const onMobileChange = (event) => {
        setMobileValue(event.currentTarget.value)
    }

    const onCityChange = (event) => {
        setCityValue(event.currentTarget.value)
    }

    const onHouseNameChange = (event) => {
        setHouseNameValue(event.currentTarget.value)
    }

    const onPincodeChange = (event) => {
        setPincodeValue(event.currentTarget.value)
    }

    const onAreaChange = (event) => {
        setAreaValue(event.currentTarget.value)
    }

    const onLandmarkChange = (event) => {
        setLandmarkValue(event.currentTarget.value)
    }

    const onStateChange = (event) => {
        setStateValue(event.currentTarget.value)
    }

    const onCountryChange = (event) => {
        setCountryValue(event.currentTarget.value)
    }

    const onSubmit = (event) => {
        event.preventDefault();


        if (!NameValue || !MobileValue || !HouseNameValue ||
           !CityValue  || !PincodeValue  || !AreaValue  ||
           !CountryValue  || !StateValue) {
            return alert('fill all the fields first!')
        }

        const variables = {
            writer: props.user.userData._id,
            name: NameValue,
            mobile: MobileValue,
            pincode: PincodeValue,
            houseName: HouseNameValue,
            area: AreaValue,
            landmark: LandmarkValue,
            city: CityValue,
            state:StateValue,
            country: CountryValue,
        }

        axios.post('/api/address/addaddress', variables)
            .then(response => {
                if (response.data.success) {
                    alert('Address Added Successfully ')
                    props.history.push('/orderconfirm')
                } else {
                    alert('Failed to upload Address')
                }
            })

        // alert("hello")

    }

    const showadd = () =>{
        alert("hi")
    }

    const onSkip =()=>{
        props.history.push('/orderconfirm')
    }

    // display:'none'
    return (
        <div>
        <div style={{ maxWidth: '700px', margin: '2rem auto '  }}>
           
           {/* <div>
              <Title level={2}> Choose Address</Title>
              <button className="btn btn-primary" onClick={showadd}>Add a New Address</button>
           </div> */}

        </div>
        <div style={{ maxWidth: '700px', margin: '2rem auto', }}>
            <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                <Title level={2}> ADD ADDRESS</Title>
            </div>


            <Form onSubmit={onSubmit} >

    
                <br />
                <label>Full Name</label>
                <Input
                    onChange={onNameChange}
                    value={NameValue}
                />
                  
                <br />
                <br />
                <label>Mobile Number</label>
                <Input
                    onChange={onMobileChange}
                    value={MobileValue}
                    type="number"
                />

                <br />
                <br />
                <label>Pincode</label>
                <Input
                    onChange={onPincodeChange}
                    value={PincodeValue}
                    type="number"
                />

                <br />
                <br />
                <label>House Number OR House Name </label>
                <Input
                    onChange={onHouseNameChange}
                    value={HouseNameValue}
                />

                <br />
                <br />
                <label> Area / Street /Village </label>
                <Input
                    onChange={onAreaChange}
                    value={AreaValue}
                />

                <br />
                <br />
                <label> Landmark</label>
                <Input
                    onChange={onLandmarkChange}
                    value={LandmarkValue}
                />
               
                <br /><br />
                <label>City</label>
                <Input
                    onChange={onCityChange}
                    value={CityValue}
                />

                <br />
                <br />
                <label>State </label>
                <Input
                    onChange={onStateChange}
                    value={StateValue}
                />

                <br />
                <br />
                <label> Country </label>
                <Input
                    onChange={onCountryChange}
                    value={CountryValue}
                />

                <br />
                <br />

                <br />
                <br />

                <button  style={{marginRight:"20px"}} onClick={onSkip} type="button">Skip</button>

                <Button
                    onClick={onSubmit}
                >
                    Submit
                </Button>

               

            </Form>

        </div>
     </div>
    )
}

export default AddressPage
