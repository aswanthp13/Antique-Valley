import React from 'react'

function Order(props) {

  
    console.log(props.data)
    return (
        
       <tr key={props.key}>

<td> <center> <img style={{ width: '70px' ,height:"70px"}} src={props.data.images&&`http://localhost:5000/${props.data.images[0]}`} /></center> </td>
<td> <center> {props.data.title} </center> </td>
<td> <center> {props.data.price}</center> </td>
{/* <td> <center> {props.data.product_status}</center> </td> */}
<td> <center>
     <button onClick={()=> props.removeItem(props.data._id)}>Cancel Item</button>
     {/* <button style={{marginLeft:"20px"}} onClick={()=> props.addToOrder(props.data._id)} >Continue</button>  */}
</center> </td>

</tr>
    )
}

export default Order
