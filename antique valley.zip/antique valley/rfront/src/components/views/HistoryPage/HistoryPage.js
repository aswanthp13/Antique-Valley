
import React, { useEffect, useState } from 'react'
import UserCardBlock from './Sections/order';
import axios from 'axios';

function HistoryPage(props) {
  
    var [uploaddata,setUploaddata]= useState("")

    useEffect(() => {
        getFuc();
      }, []);
    const getFuc=()=>{
        axios.get(`/api/users/userOrderInfo`)
          .then(response =>{
              if(response.data){
                console.log(response.data);
                setUploaddata(response.data.orderDetail);
              }
          });
    }

    const removeFromOrder = (productId) => {
           
        axios.get(`/api/users/removeFromOrder?_id=${productId}`)
          .then(response =>{
              if(response.data){
                  alert("Order Cancelled Successfully")
                  props.history.push('/')
                console.log(response.data);
                getFuc()
              }
          });

    }


    const addToOrderitem =(productId)=>{
        // alert("hi")
        // props.history.push('/address')
        props.history.push('/')
    }

    return (
        <div style={{padding:30}}>
        <h1 >My Orders</h1>
        
            <table >
                <thead>
                    <tr>
                        <th><center>  Product Image </center></th>
                        <th><center>  Product Name </center></th>
                        <th><center>  Product Price </center></th>
                        {/* <th><center>  My Product Status </center></th> */}
                        <th><center>   </center></th>
                    </tr>
                </thead>
                <tbody >

                    {  uploaddata && uploaddata.length!==0 && uploaddata.map((item,i) =>       
                        <UserCardBlock data={item} key={i}  
                              removeItem={removeFromOrder} 
                              addToOrder={addToOrderitem} />
                       )}
                   
                </tbody>
                </table>
        
     {/* {  uploaddata && uploaddata.length!==0 && uploaddata.map((item,i) =>       
        <div key={i}>

              <h1> {item.price} </h1>
              <img  style={{width:'20px',height:'20px'}} src={item.images&&`http://localhost:5000/${item.images[0]}`}  />
        
        </div>)} */}

        </div>
    )
}

export default HistoryPage

















// import React from 'react'

// function HistoryPage(props) {

//     return (
//         <div style={{ width: '80%', margin: '3rem auto' }}>
//             <div style={{ textAlign: 'center' }}>
//                 <h1>History</h1>
//             </div>
//             <br />

//             <table>
//                 <thead>
//                     <tr>
//                         <th>Payment Id</th>
//                         <th>Price</th>
//                         <th>Quantity</th>
//                         <th>Date of Purchase</th>
//                     </tr>
//                 </thead>

//                 <tbody>

//                     {/* {props.user.userData && props.user.userData.history &&
//                         props.user.userData.history.map(item => (
//                             <tr key={item.id}>
//                                 <td>{item.id}</td>
//                                 <td>{item.price}</td>
//                                 <td>{item.quantity}</td>
//                                 <td>{item.dateOfPurchase}</td>
//                             </tr>
//                         ))} */}
//                         <tr >
//                                 <td>gfgf</td>
//                                 <td>gfgf</td>
//                                 <td>gggg</td>
//                                 <td>ggggg</td>
//                             </tr>


//                 </tbody>
//             </table>
//         </div>
//     )
// }

// export default HistoryPage
