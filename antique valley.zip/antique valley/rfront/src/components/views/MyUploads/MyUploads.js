import React, { useEffect, useState } from 'react'

import UserCardBlock from './Sections/UserCardBlock';

import axios from 'axios';
function MyUploads(props) {
  
    var [uploaddata,setUploaddata]= useState("")

    useEffect(() => {
        getFuc();
      }, []);
    const getFuc=()=>{
        axios.get(`/api/users/getMyProducts`)
          .then(response =>{
              if(response.data){
                console.log(response.data);
                setUploaddata(response.data.uploadDetail);
              }
          });
    }
    return (
        <div style={{padding:30}}>
        <h1 >My Uploads</h1>
        
            <table >
                <thead>
                    <tr>
                        <th><center>  Product Image </center></th>
                        <th><center>  Product Name </center></th>
                        <th><center>  Product Price </center></th>
                        <th><center>  My Product Status </center></th>
                        {/* <th><center>  Remove from Cart </center></th> */}
                    </tr>
                </thead>
                <tbody >

                    {  uploaddata && uploaddata.length!==0 && uploaddata.map((item,i) =>       
                        <UserCardBlock data={item} key={i} />
                       )}
                   
                </tbody>
                </table>
        
     {/* {  uploaddata && uploaddata.length!==0 && uploaddata.map((item,i) =>       
        <div key={i}>

              <h1> {item.price} </h1>
              <img  style={{width:'20px',height:'20px'}} src={item.images&&`http://localhost:5000/${item.images[0]}`}  />
        
        </div>)} */}

        </div>
    )
}

export default MyUploads
