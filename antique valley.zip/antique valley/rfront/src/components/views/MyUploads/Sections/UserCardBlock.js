import React from 'react'

function UserCardBlock(props) {


    // const renderItems = () => (
    //     props.products && props.products.map(product => (
    //         <tr key={product._id}>
    //             <td>{product.images&&product.images.map((src,i)=>
    //                 <img style={{ width: '70px' }} key={i} alt="product" 
    //                 src={src} />)}
    //             </td> 
    //             <td>{product.quantity} </td>
    //             <td>₹ {product.price} </td>
    //             <td><button 
    //             onClick={()=> props.removeItem(product._id)}
    //             >Remove </button> </td>
    //         </tr>
    //     ))
    // )

  
    console.log(props.data)
    return (
        
       <tr key={props.key}>

<td> <center> <img style={{ width: '70px' ,height:"70px"}} src={props.data.images&&`http://localhost:5000/${props.data.images[0]}`} /></center> </td>
<td> <center> {props.data.title} </center> </td>
<td> <center> {props.data.price}</center> </td>
<td> <center> {props.data.product_status}</center> </td>
{/* <td> <center> <button>Remove</button> </center> </td> */}

</tr>
    )
}

export default UserCardBlock
