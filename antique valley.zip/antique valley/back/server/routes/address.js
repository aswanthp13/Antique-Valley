const express = require('express');
const router = express.Router();
const { Address } = require("../models/Address");
const { auth } = require("../middleware/auth");
const { User } = require("../models/User");

//=================================
//             Address
//=================================



router.post("/addaddress", auth, (req, res) => {

    //save all the data we got from the client into the DB 
    const address = new Address(req.body)

    address.save((err) => {
        if (err) return res.status(400).json({ success: false, err })
        return res.status(200).json({ success: true })
    })

});





router.get("/addressbyid",auth, (req, res) => {
    
    User.findOne({ _id: req.user._id},
    (err, userInfo) => {
        let usr=userInfo._id
      Address.find({writer:usr})
              .then(address =>{
                  res.json({
                      address
                  })
                  console.log("Get all address successfully!")
              })
              .catch(error =>{
                  res.json({
                      message:'An error Occured !'
                  })
              })
    });
   
});




module.exports = router;
