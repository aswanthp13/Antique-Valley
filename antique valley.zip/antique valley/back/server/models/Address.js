const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const addressSchema = mongoose.Schema({
    writer: {
        type: Schema.Types.ObjectId,
        ref: 'User'
    },
    name: {
        type: String,
        maxlength: 50
    },
    mobile: {
        type: Number,
    },
    houseName: {
        type: String
    },
    pincode: {
        type: Number,
    },
    area: {
        type: String
    },
    landmark: {
        type: String
    },
    city: {
        type: String
    },
    state: {
        type: String
    },  
    country: {
        type: String
    },   
    
}, { timestamps: true })


addressSchema.index({ 
    name:'text',
    houseName: 'text',
}, {
    weights: {
        name: 5,
        houseName: 1,
    }
})

const Address = mongoose.model('Address', addressSchema);

module.exports = { Address }